package ru.job4j.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class Test {
    public static void main(String[] args) {
        try (InputStream in = new FileInputStream("/mytest/test.txt")) {
            System.out.println(in);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
