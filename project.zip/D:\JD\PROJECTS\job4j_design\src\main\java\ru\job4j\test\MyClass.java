package ru.job4j.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyClass {
    public static void main(String[] args) {
        int[] A = new int[]{9, 3, 5, 1, 15};
        int[] K_Array = new int[]{2, 10};
        int N = 5;
        int K = 2;
        System.out.println(Arrays.toString(process_queries(A, K_Array, N, K)));
    }

    static int[] process_queries(int[] A, int[] K_Array, int N, int K) {
        int[] res = new int[K];
        for (int i = 0; i < K; i++) {
            List list = new ArrayList();
            for (int j = 0; j < N; j++) {
                if (A[j] > K_Array[i]) {
                    list.add(A[j]);
                }
            }
            res[i] = list.size();
        }
        return res;
    }
}
