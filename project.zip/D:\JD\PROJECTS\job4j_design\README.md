# job4j_design
[![Build Status](https://travis-ci.com/NikolayPol/job4j_design.svg?branch=master)](https://travis-ci.com/NikolayPol/job4j_design)
[![codecov](https://codecov.io/gh/NikolayPol/job4j_design/branch/master/graph/badge.svg?token=RT7OBT3AF2)](https://codecov.io/gh/NikolayPol/job4j_design)